# =============================================================================
# 01b — Plantillas de codificación humana a ciegas (Jari y Silvio)
# =============================================================================

canciones <- read_csv(file.path(RUTAS$proc, "canciones_unicas.csv"), show_col_types = FALSE)

crear_hoja <- function(datos, archivo) {
  hoja <- datos |>
    arrange(id) |>
    transmute(id, titulo, artista_principal,
              tema_principal = "", explicito_sexual = "", notas = "")
  if (file.exists(archivo)) {
    message("Ya existe ", archivo, ": no se sobrescribe.")
  } else {
    write_csv(hoja, archivo, na = "")
    message("Plantilla creada: ", archivo)
  }
}

# Aviso si una hoja de validación vieja aún usa la columna "explicito" (libro v1)
for (archivo in list.files(RUTAS$val, pattern = "^codificacion_.*\\.csv$", full.names = TRUE)) {
  if ("explicito" %in% names(read_csv(archivo, n_max = 0, show_col_types = FALSE))) {
    warning(basename(archivo), " usa la columna 'explicito' (libro v1). ",
            "Si está vacía, bórrala y vuelve a correr main.R para crearla con 'explicito_sexual'.")
  }
}

for (codificador in c("Jari", "Silvio")) {
  crear_hoja(filter(canciones, en_piloto),
             file.path(RUTAS$val, paste0("piloto_", codificador, ".csv")))
  crear_hoja(filter(canciones, en_validacion),
             file.path(RUTAS$val, paste0("codificacion_", codificador, ".csv")))
}
