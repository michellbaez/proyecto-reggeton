# =============================================================================
# 02a — Limpieza automática de las letras (en memoria) y reporte
#
# Reglas aprobadas por el equipo:
#   R1. Encabezado de página: se elimina la primera línea si empieza con
#       "Letra ..." o "Lyrics ..." (Musixmatch, español o inglés).
#   R2. Etiquetas de sección: se eliminan las líneas que son solo una etiqueta
#       (Coro, Verso, Chorus, Verse, Hook, Intro, Outro, Puente, Bridge, ...),
#       con o sin corchetes, número o nombre del artista tras ":".
#       También se eliminan las líneas completas entre corchetes, p. ej. [Coro].
#   R3. Marcas de repetición: se elimina solo la marca ("x2", "(x3)", "[x2]",
#       "×2", "(bis)") al final de la línea; el resto de la línea se conserva.
#       Expresiones dentro del verso como "4 x 4" NO se tocan.
# =============================================================================

PATRON_ENCABEZADO <- "(?i)^(letra|lyrics)\\b"

ETIQUETAS <- paste(
  "pre[- ]?coro", "coro", "estribillo", "verso", "puente", "interludio", "refr[a\\x{00E1}]n",
  "pre[- ]?chorus", "post[- ]?chorus", "chorus", "verse", "bridge", "hook",
  "intro", "outro", "interlude", "refrain",
  sep = "|"
)
PATRON_ETIQUETA  <- paste0("(?i)^[\\[\\(]?\\s*(", ETIQUETAS, ")\\s*\\d*\\s*(:[^\\]\\)]{0,60})?[\\]\\)]?\\s*$")
PATRON_CORCHETES <- "^\\[[^\\]]*\\]$"
# (Los caracteres "á" y "×" se escriben como \\x{...} para que funcione en cualquier sistema)
# Marca entre paréntesis/corchetes: (x2), [x 3], (2x), (bis)
# Marca suelta al final: " x2", " ×3", " bis"  (no si va precedida de un número: "4 x 4")
PATRON_REPETICION <- paste0(
  "(?i)(?:\\s*[\\(\\[]\\s*(?:[x\\x{00D7}]\\s?\\d{1,2}|\\d{1,2}\\s?[x\\x{00D7}]|bis)\\s*[\\)\\]]",
  "|(?<!\\d)(?<!\\d\\s)\\s+(?:[x\\x{00D7}]\\d{1,2}|bis))\\s*$"
)

limpiar_letra <- function(lineas) {
  lineas <- trimws(lineas)
  lineas <- lineas[lineas != ""]
  log <- list()

  # R1 — encabezado (solo la primera línea)
  if (length(lineas) > 0 && grepl(PATRON_ENCABEZADO, lineas[1], perl = TRUE)) {
    log[[length(log) + 1]] <- tibble(regla = "R1_encabezado", linea = 1L, eliminado = lineas[1])
    lineas[1] <- ""
  }

  # R2 — etiquetas de sección
  es_etiqueta <- grepl(PATRON_ETIQUETA, lineas, perl = TRUE) |
                 grepl(PATRON_CORCHETES, lineas, perl = TRUE)
  es_etiqueta <- es_etiqueta & lineas != ""
  if (any(es_etiqueta)) {
    log[[length(log) + 1]] <- tibble(regla = "R2_etiqueta", linea = which(es_etiqueta),
                                     eliminado = lineas[es_etiqueta])
    lineas[es_etiqueta] <- ""
  }

  # R3 — marcas de repetición al final de la línea
  tiene_marca <- lineas != "" & grepl(PATRON_REPETICION, lineas, perl = TRUE)
  if (any(tiene_marca)) {
    marcas <- regmatches(lineas[tiene_marca],
                         regexpr(PATRON_REPETICION, lineas[tiene_marca], perl = TRUE))
    log[[length(log) + 1]] <- tibble(regla = "R3_marca_repeticion", linea = which(tiene_marca),
                                     eliminado = trimws(marcas))
    lineas[tiene_marca] <- trimws(sub(PATRON_REPETICION, "", lineas[tiene_marca], perl = TRUE))
  }

  list(lineas = lineas[lineas != ""], log = bind_rows(log))
}

# --- Aplicar a las 160 letras ------------------------------------------------
rutas_txt <- list.files(RUTAS$letras, pattern = "\\.txt$", recursive = TRUE, full.names = TRUE)
names(rutas_txt) <- gsub("_", "-", tools::file_path_sans_ext(basename(rutas_txt)))

resultado <- lapply(names(rutas_txt), function(id) {
  originales <- readLines(rutas_txt[[id]], encoding = "UTF-8", warn = FALSE)
  limpio <- limpiar_letra(originales)
  list(
    lineas = limpio$lineas,
    log = if (nrow(limpio$log) > 0) mutate(limpio$log, id = id, .before = 1) else NULL,
    resumen = tibble(id = id,
                     lineas_originales = sum(trimws(originales) != ""),
                     lineas_finales    = length(limpio$lineas))
  )
})
names(resultado) <- names(rutas_txt)

# Texto limpio: SOLO en memoria, para los módulos siguientes
letras_limpias <- lapply(resultado, `[[`, "lineas")

# --- Reporte de limpieza (sin letra) ----------------------------------------
detalle <- bind_rows(lapply(resultado, `[[`, "log"))
resumen <- bind_rows(lapply(resultado, `[[`, "resumen")) |>
  left_join(count(detalle, id, regla) |>
              tidyr::pivot_wider(names_from = regla, values_from = n, values_fill = 0),
            by = "id") |>
  mutate(across(starts_with("R"), ~ tidyr::replace_na(.x, 0L))) |>
  arrange(id)

for (col in c("R1_encabezado", "R2_etiqueta", "R3_marca_repeticion")) {
  if (!col %in% names(resumen)) resumen[[col]] <- 0L
}

write_csv(detalle, file.path(RUTAS$tablas, "reporte_limpieza_detalle.csv"))
write_csv(resumen, file.path(RUTAS$tablas, "reporte_limpieza_resumen.csv"))

message(sprintf(
  "Limpieza: %d encabezados, %d etiquetas y %d marcas de repetición eliminados en %d letras.",
  sum(resumen$R1_encabezado), sum(resumen$R2_etiqueta),
  sum(resumen$R3_marca_repeticion), nrow(resumen)
))
