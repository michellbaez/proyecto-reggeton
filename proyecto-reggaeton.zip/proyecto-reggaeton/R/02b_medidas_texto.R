# =============================================================================
# 02b — Medidas de texto: diversidad léxica (MTLD)
#
# Decisiones aprobadas por el equipo:
#   D8: medida única = MTLD (McCarthy y Jarvis, 2010), umbral TTR = 0.72,
#       promedio de la pasada hacia adelante y hacia atrás
#   D7: a. todo en minúsculas
#       b. se conservan las tildes ("tú" ≠ "tu")
#       c. las elisiones se leen como la palabra completa (pa' = para)
#       d. se eliminan vocables y ad-libs (yeh, eh, prr, uh...) con lista documentada
#       e. se conservan las firmas de artistas ("J Balvin, man")
#       f. NO se eliminan palabras vacías (de, la, que)
#   Las canciones en inglés o mixtas se miden igual (marcadas en el registro).
# =============================================================================

UMBRAL_MTLD <- 0.72

# Factores de una pasada (McCarthy y Jarvis, 2010):
# se acumula la TTR palabra a palabra; cuando cae a 0.72 o menos se cuenta
# un factor completo y se reinicia. Lo que queda al final aporta un factor
# parcial = (1 - TTR_restante) / (1 - 0.72).
mtld_pasada <- function(tokens, umbral = UMBRAL_MTLD) {
  factores <- 0
  tipos <- character(0)
  n_seg <- 0
  ttr <- 1
  for (tk in tokens) {
    n_seg <- n_seg + 1
    if (!(tk %in% tipos)) tipos <- c(tipos, tk)
    ttr <- length(tipos) / n_seg
    if (ttr <= umbral) {
      factores <- factores + 1
      tipos <- character(0); n_seg <- 0; ttr <- 1
    }
  }
  if (n_seg > 0) factores <- factores + (1 - ttr) / (1 - umbral)
  if (factores == 0) return(NA_real_)   # texto sin ninguna repetición: MTLD indefinido
  length(tokens) / factores
}

mtld <- function(tokens, umbral = UMBRAL_MTLD) {
  mean(c(mtld_pasada(tokens, umbral), mtld_pasada(rev(tokens), umbral)))
}

# Prueba de control del cálculo:
# "a b a b a b" -> la TTR cae a 2/3 en las palabras 3 y 6 -> 2 factores -> 6/2 = 3
stopifnot(isTRUE(all.equal(mtld(c("a", "b", "a", "b", "a", "b")), 3)))

# --- Normalización ----------------------------------------------------------

# D7-c. Elisiones: lista explícita (se aplica primero) + reglas generales
ELISIONES <- c(
  "pa'l" = "para el", "pa'" = "para", "pa'lante" = "para adelante",
  "pa'trás" = "para atrás", "pa'cá" = "para acá", "p'acá" = "para acá",
  "p'allá" = "para allá", "p'" = "para",
  "to'" = "todo", "to'a" = "toda", "to'as" = "todas", "to'os" = "todos", "toa'" = "todas",
  "na'" = "nada", "na'más" = "nada más", "e'" = "es", "ta'" = "está",
  "vo'a" = "voy a", "vamo'a" = "vamos a", "uste'" = "usted", "lao'" = "lado",
  "die'" = "diez", "yo'" = "yo", "leggo'" = "leggo", "tranqui'" = "tranqui"
)
# Reglas generales (en este orden):
#   -a'o / -a'os -> -ado / -ados   (pega'o -> pegado)
#   -i'o / -i'os -> -ido / -idos   (prendi'o -> prendido)
#   -a'a / -a'as -> -ada / -adas   (prendi'a sigue la regla i'a -> ida)
#   palabra terminada en vocal + ' -> + s   (vamo' -> vamos, nene' -> nenes)
aplicar_elisiones <- function(tokens) {
  en_lista <- tokens %in% names(ELISIONES)
  tokens[en_lista] <- ELISIONES[tokens[en_lista]]
  tokens <- sub("a'o(s?)$", "ado\\1", tokens, perl = TRUE)
  tokens <- sub("i'o(s?)$", "ido\\1", tokens, perl = TRUE)
  tokens <- sub("a'a(s?)$", "ada\\1", tokens, perl = TRUE)
  tokens <- sub("i'a(s?)$", "ida\\1", tokens, perl = TRUE)
  tokens <- sub("([aeiou\\x{00e1}\\x{00e9}\\x{00ed}\\x{00f3}\\x{00fa}])'$", "\\1s", tokens, perl = TRUE)
  tokens <- gsub("'", "", tokens)             # apóstrofos que queden
  unlist(strsplit(tokens, " ", fixed = TRUE)) # "para el" -> dos palabras
}

#Vocables y ad-libs: lista + patrón (palabras formadas solo por
# sonidos repetidos). Las vocales sueltas "a", "e", "o", "u" no se eliminan
# porque son preposición o conjunción.
VOCABLES <- c("yeh", "yeah", "yah", "eh", "ey", "ayé", "oh", "uh", "uoh", "ah",
              "prr", "brr", "wuh", "woh", "wow", "mmh", "mm", "hmm", "hey",
              "ayy", "uff", "jaja", "jeje", "ja", "je", "uah", "ouh", "ooh", "na", "la")
PATRON_VOCABLE <- "^(?:[aeiou]{2,}h*|[aeiou]h+|h[aeiou]+h*|m{2,}h*|pr{2,}|br{2,}|(?:ja){2,}|(?:je){2,}|ye+a*h+|uo+h+|ay{2,}|ey{2,})$"
# Nota: "na" y "la" solo se eliminan cuando forman cadenas de vocables
# ("na na na"); ver es_vocable().

es_vocable <- function(tokens) {
  base <- tokens %in% setdiff(VOCABLES, c("na", "la")) |
          grepl(PATRON_VOCABLE, tokens, perl = TRUE)
  # "na" / "la" solo cuando aparecen 3 o más veces seguidas (estribillo vocal)
  for (v in c("na", "la")) {
    r <- rle(tokens == v)
    largos <- rep(r$values & r$lengths >= 3, r$lengths)
    base <- base | largos
  }
  base
}

tokenizar <- function(lineas) {
  texto <- enc2utf8(paste(lineas, collapse = " "))
  texto <- tolower(texto)
  for (ap in c("\u2019", "\u2018", "\u00b4", "`")) {               # apóstrofos tipográficos
    texto <- gsub(ap, "'", texto, fixed = TRUE)
  }
  tokens <- unlist(strsplit(texto, "[^\\p{L}\\p{N}']+", perl = TRUE))
  tokens <- gsub("^'+|(?<=[^aeiou\\x{00e1}\\x{00e9}\\x{00ed}\\x{00f3}\\x{00fa}])'+$", "", tokens, perl = TRUE)
  tokens <- tokens[tokens != ""]
  originales <- tokens
  tokens <- aplicar_elisiones(tokens)                            # D7-c
  vocable <- es_vocable(tokens)                                  # D7-d
  list(tokens = tokens[!vocable],
       vocables_eliminados = tokens[vocable],
       elisiones = originales[grepl("'", originales)])
}

# --- Cálculo por canción ------------------------------------------------------
resultado_texto <- lapply(names(letras_limpias), function(id) {
  tk <- tokenizar(letras_limpias[[id]])
  list(
    medidas = tibble(
      id = id,
      n_tokens  = length(tk$tokens),
      n_tipos   = length(unique(tk$tokens)),
      ttr       = n_tipos / n_tokens,
      mtld      = mtld(tk$tokens),
      n_vocables_eliminados = length(tk$vocables_eliminados),
      n_elisiones_unificadas = length(tk$elisiones)
    ),
    tokens = tk$tokens, vocables = tk$vocables_eliminados, elisiones = tk$elisiones
  )
})
names(resultado_texto) <- names(letras_limpias)

medidas_texto <- bind_rows(lapply(resultado_texto, `[[`, "medidas")) |> arrange(id)
stopifnot(nrow(medidas_texto) == 160, !any(is.na(medidas_texto$mtld)))
write_csv(medidas_texto, file.path(RUTAS$proc, "medidas_texto.csv"))

# --- Reportes de normalización y frecuencias (palabras sueltas, sin letra) ---
contar <- function(campo) {
  bind_rows(lapply(names(resultado_texto), function(id)
    tibble(id = id, palabra = resultado_texto[[id]][[campo]]))) |>
    group_by(palabra) |>
    summarise(frecuencia = n(), n_canciones = n_distinct(id), .groups = "drop") |>
    arrange(desc(frecuencia))
}
write_csv(contar("vocables"),  file.path(RUTAS$tablas, "reporte_02b_vocables_eliminados.csv"))
write_csv(contar("elisiones"), file.path(RUTAS$tablas, "reporte_02b_elisiones_unificadas.csv"))
# Base para construir el léxico (D9-A): frecuencia de cada palabra en el corpus
write_csv(contar("tokens"),    file.path(RUTAS$tablas, "frecuencias_palabras_corpus.csv"))

message(sprintf("MTLD calculado para %d letras (mediana = %.1f, rango %.1f–%.1f).",
                nrow(medidas_texto), median(medidas_texto$mtld),
                min(medidas_texto$mtld), max(medidas_texto$mtld)))
