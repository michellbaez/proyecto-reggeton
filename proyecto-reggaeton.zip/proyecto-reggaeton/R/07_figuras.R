# =============================================================================
# 07 — Figuras del informe
# =============================================================================

library(ggplot2)
tema_apa <- theme_minimal(base_size = 11, base_family = "sans") +
  theme(panel.grid.minor = element_blank(), legend.position = "bottom",
        plot.margin = margin(8, 12, 8, 8))
guardar <- function(g, nombre, alto = 3.6) {
  ggsave(file.path(RUTAS$fig, nombre), g, width = 6.5, height = alto, dpi = 300, bg = "white")
}
base_f <- read_csv("data/base_analitica.csv", show_col_types = FALSE)

# Figura 1 — MTLD por año (mediana, rango intercuartílico y pendiente de Sen)
serie_f <- base_f |> group_by(anio) |>
  summarise(mediana = median(mtld), q1 = quantile(mtld, .25), q3 = quantile(mtld, .75), .groups = "drop")
pares_f <- combn(nrow(serie_f), 2)
sen_f <- median((serie_f$mediana[pares_f[2, ]] - serie_f$mediana[pares_f[1, ]]) /
                (serie_f$anio[pares_f[2, ]] - serie_f$anio[pares_f[1, ]]))
intercepto_f <- median(serie_f$mediana - sen_f * serie_f$anio)
g1 <- ggplot(serie_f, aes(anio, mediana)) +
  annotate("rect", xmin = 2012.5, xmax = 2025.5, ymin = -Inf, ymax = Inf, alpha = .06) +
  geom_linerange(aes(ymin = q1, ymax = q3), colour = "grey55", linewidth = .8) +
  geom_point(size = 2.4, colour = "#1f4e79") +
  geom_abline(intercept = intercepto_f, slope = sen_f, linetype = "dashed", colour = "#c0504d") +
  annotate("text", x = 2013, y = max(serie_f$q3), label = "Era streaming", hjust = 0, size = 3.2, colour = "grey35") +
  scale_x_continuous(breaks = 2010:2025, limits = c(2009.5, 2025.6)) +
  labs(x = "Año", y = "MTLD (palabras)") + tema_apa +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
guardar(g1, "figura_1_mtld_anual.png")

# Figura 2 — MTLD Colombia vs. Puerto Rico (2013–2025)
s1_f <- base_f |> filter(era_streaming == "streaming", pais_s1 %in% c("colombia", "puerto_rico")) |>
  mutate(pais = factor(pais_s1, c("colombia", "puerto_rico"),
                       c(sprintf("Colombia (n = %d)", sum(pais_s1 == "colombia")),
                         sprintf("Puerto Rico (n = %d)", sum(pais_s1 == "puerto_rico")))))
set.seed(SEMILLA)
g2 <- ggplot(s1_f, aes(pais, mtld)) +
  geom_boxplot(width = .45, outlier.shape = NA, fill = "grey92") +
  geom_jitter(width = .12, size = 1.6, alpha = .6, colour = "#1f4e79") +
  labs(x = NULL, y = "MTLD (palabras)") + tema_apa
guardar(g2, "figura_2_mtld_pais.png", alto = 3.4)

# Figura 3 — Distribución de temas por era (codificación del LLM)
etiquetas_tema <- c(amor_romance = "Amor", desamor_despecho = "Desamor", seduccion_deseo = "Seducción",
                    fiesta_baile = "Fiesta", ostentacion_exito = "Ostentación", otro = "Otro")
t3 <- base_f |> count(era_streaming, tema_llm) |> group_by(era_streaming) |>
  mutate(prop = n / sum(n)) |> ungroup() |>
  mutate(era = factor(era_streaming, c("pre_streaming", "streaming"),
                      c("2010–2012 (n = 30)", "2013–2025 (n = 117)")),
         tema = factor(etiquetas_tema[tema_llm], rev(etiquetas_tema)))
g3 <- ggplot(t3, aes(prop, era, fill = tema)) +
  geom_col(width = .6, colour = "white") +
  geom_text(aes(label = ifelse(prop >= .06, scales::percent(prop, 1), "")),
            position = position_stack(vjust = .5), size = 3, colour = "white") +
  scale_x_continuous(labels = scales::percent) +
  scale_fill_manual(values = c(Amor = "#1f4e79", Desamor = "#5b9bd5", Seducción = "#c0504d",
                               Fiesta = "#ed7d31", Ostentación = "#7f7f7f", Otro = "#bfbfbf"),
                    breaks = etiquetas_tema) +
  labs(x = "Proporción de canciones", y = NULL, fill = NULL) + tema_apa
guardar(g3, "figura_3_temas_era.png", alto = 2.8)

# Figura 4 — Proporción anual de canciones con contenido sexual explícito y ajuste logístico
modelo_f <- glm(I(explicito_sexual_llm == "si") ~ anio, data = base_f, family = binomial)
rejilla <- tibble(anio = seq(2010, 2025, by = .1))
pred <- predict(modelo_f, rejilla, type = "link", se.fit = TRUE)
rejilla <- rejilla |> mutate(p = plogis(pred$fit), inf = plogis(pred$fit - 1.96 * pred$se.fit),
                             sup = plogis(pred$fit + 1.96 * pred$se.fit))
anual_f <- base_f |> group_by(anio) |>
  summarise(prop = mean(explicito_sexual_llm == "si"), n = n(), .groups = "drop")
g4 <- ggplot() +
  geom_ribbon(data = rejilla, aes(anio, ymin = inf, ymax = sup), fill = "#c0504d", alpha = .15) +
  geom_line(data = rejilla, aes(anio, p), colour = "#c0504d", linewidth = .9) +
  geom_point(data = anual_f, aes(anio, prop), size = 2.4, colour = "#1f4e79") +
  scale_x_continuous(breaks = 2010:2025) +
  scale_y_continuous(labels = scales::percent, limits = c(0, 1)) +
  labs(x = "Año", y = "Canciones explícitas") + tema_apa +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
guardar(g4, "figura_4_explicito_anual.png")

message("07: figuras guardadas en ", RUTAS$fig)
