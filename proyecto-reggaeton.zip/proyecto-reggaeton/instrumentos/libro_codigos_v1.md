# Libro de códigos — v1

**Proyecto:** Estadística del Reggaetón · Estadística Industrial · Universidad del Magdalena
**Versión:** 1 (borrador para prueba piloto) · **Fecha:** 2026-10-24
**Codificadores humanos:** Jari, Silvio · **Instrumento automatizado:** Claude (mismo libro + prompt fijo)

> Si este documento cambia después del piloto, se guarda como `libro_codigos_v2.md` y esta versión **no se borra**.

---

## 1. Reglas generales

1. **Unidad de codificación:** la canción completa, leída de principio a fin.
2. **Se codifica solo el texto de la letra.** No se usa el videoclip, la fama del artista, entrevistas ni lo que se sepa de la canción por fuera.
3. **Canciones en inglés o en mezcla de idiomas** se codifican con las mismas reglas.
4. Cada canción recibe **dos códigos independientes**: `tema_principal` (una sola categoría) y `explicito` (sí/no). Uno no condiciona al otro.
5. **Ejemplos del libro (D5-C):** cada ejemplo y contraejemplo trae una **paráfrasis** del pasaje y una **cita textual** de máximo 6 palabras con su canción y artista. Las canciones de ejemplo están fuera de la submuestra de validación y del piloto.
6. En `notas` se escribe en una frase **por qué** se eligió el código cuando hubo duda. Esas notas son la materia prima del análisis de discrepancias.
7. La codificación es **individual y a ciegas**: sin hablar con el otro codificador, sin ver su hoja, sin ver la salida del LLM y sin usar IA.

---

## 2. Variable `tema_principal`

**Regla de asignación (D1-A):** se asigna la categoría cuyo tema **ocupa la mayor parte de la letra**, contando las líneas tal como aparecen (un coro que se repite cuenta cada vez que aparece).

**Regla de desempate** (cuando dos temas ocupan una parte similar de la letra):
1. Gana el **tema del coro** (la parte que se repite como estribillo).
2. Si la canción **no tiene coro claro**, se aplica una **jerarquía fija por especificidad** (de la categoría más concreta a la más general):
   `ostentacion_exito` > `desamor_despecho` > `seduccion_deseo` > `amor_romance` > `fiesta_baile`.
   `otro` no entra en la jerarquía: solo se usa cuando ninguna de las cinco categorías cubre la mayor parte de la letra.

**Valores válidos** (escribirlos exactamente así en la hoja):

| Código | Categoría |
|---|---|
| `amor_romance` | Amor / romance |
| `desamor_despecho` | Desamor / despecho |
| `seduccion_deseo` | Seducción / deseo |
| `fiesta_baile` | Fiesta / baile |
| `ostentacion_exito` | Ostentación / éxito / dinero |
| `otro` | Otro |

### 2.1 `amor_romance`
- **Definición operativa:** la letra expresa afecto, compromiso o idealización de una relación **vigente o deseada como relación**, no solo como encuentro.
- **Incluye:** declaraciones de amor, promesas de permanencia, aceptación de la pareja, ternura, celebración de estar juntos.
- **Excluye:** el atractivo físico o el deseo de un encuentro sin referencia a la relación (→ `seduccion_deseo`); la pérdida o el temor a perder la relación como eje (→ `desamor_despecho`).
- **Ejemplo:** *Corazón Sin Cara* — Prince Royce (2011-01).
  - Paráfrasis: El cantante le dice a su pareja que la quiere tal como es, sin importar su peso, su color o que no use maquillaje.
  - Cita: «yo te quiero así» (máx. 6 palabras)
- **Contraejemplo:** *Llévame Contigo* — Romeo Santos (2013-07). Habla de amor, pero el eje es la súplica ante la partida y la ruptura → `desamor_despecho`.
  - Paráfrasis: El narrador le ruega a su pareja que no se vaya de viaje sin él y le reprocha que trate su matrimonio como algo desechable.
  - Cita: «no aguanto la aflicción» (máx. 6 palabras)

### 2.2 desamor_despecho
- *Definición operativa:* el eje es una relación *terminada, rota o en crisis*: dolor, nostalgia, reproche, venganza o la actitud de "ya no te necesito".
- *Incluye:* ruptura, infidelidad sufrida, ex pareja, superar a alguien, salir de fiesta para olvidar.
- *Excluye:* invitar a alguien a dejar a su pareja para estar con quien canta (→ seduccion_deseo).
- *Ejemplo:* Tusa — Karol G y Nicki Minaj (2020-02).
  - Paráfrasis: Una mujer sale de fiesta con su amiga para olvidar a un hombre que la trató mal, pero se derrumba cuando suena la canción de él.
  - Cita: «Llorando lo comienza a llamar» (máx. 6 palabras)
- *Contraejemplo:* Sigues Con Él — Arcángel y Sech (2020-07). Hay una tercera persona y una relación en crisis, pero el eje es convencerla de un encuentro → seduccion_deseo.
  - Paráfrasis: El cantante le pregunta a una mujer por qué sigue con su novio si ella le confesó que él no la satisface, y la invita a probar con él.
  - Cita: «Dime por qué sigues con él» (máx. 6 palabras)

### 2.3 seduccion_deseo
- *Definición operativa:* el eje es la *atracción, la conquista o el deseo de un encuentro* íntimo con otra persona. La categoría describe de qué trata la canción; qué tan directo lo dice se mide aparte en explicito.
- *Incluye:* coqueteo, propuestas, describir el atractivo de alguien con intención de conquista, invitaciones a pasar la noche juntos.
- *Excluye:* el baile como actividad principal, aunque sea sensual (→ fiesta_baile); el lujo como tema central (→ ostentacion_exito).
- *Ejemplo:* Propuesta Indecente — Romeo Santos (2013-05).
  - Paráfrasis: El cantante se presenta ante una mujer que tiene pareja y le propone una aventura secreta esa misma noche, después de una copa.
  - Cita: «permíteme apreciar tu desnudez» (máx. 6 palabras)
- *Contraejemplo:* Ginza — J Balvin (2015-05). Tiene insinuaciones, pero la mayor parte de la letra es la invitación a seguir bailando → fiesta_baile.
  - Paráfrasis: El cantante le pide a una mujer que no deje de bailar en la discoteca; hay insinuaciones, pero la mayor parte de la letra es la invitación al baile.
  - Cita: «Vamos a pegarnos como animales» (máx. 6 palabras)

### 2.4 fiesta_baile
- *Definición operativa:* el eje es la *rumba, la discoteca, el baile o el ambiente festivo* como experiencia en sí misma.
- *Incluye:* instrucciones de baile, celebración, beber o "prender" la fiesta, perreo como actividad.
- *Excluye:* la fiesta como escenario para conquistar a una persona concreta, cuando la conquista ocupa más letra (→ seduccion_deseo); la fiesta para olvidar a una ex (→ desamor_despecho).
- *Ejemplo:* Limbo — Daddy Yankee (2013-02).
  - Paráfrasis: La letra da instrucciones para bailar el limbo y describe un ambiente de rumba, calor y gente bailando.
  - Cita: «Suelta la cadera y mueve todo» (máx. 6 palabras)
- *Contraejemplo:* Despacito — Luis Fonsi y Daddy Yankee (2017-01). Menciona bailar, pero la mayor parte es deseo dirigido a una persona → seduccion_deseo.
  - Paráfrasis: El cantante dice que quiere bailar con una mujer, pero casi toda la letra describe cómo quiere acercarse físicamente a ella, paso a paso.
  - Cita: «Tengo que bailar contigo hoy» (máx. 6 palabras)

### 2.5 `ostentacion_exito`
- **Definición operativa:** el eje es mostrar **dinero, lujo, marcas, carros, joyas, fama o ascenso social** de quien canta.
- **Incluye:** "de abajo hasta arriba", exhibir posesiones, presumir estatus.
- **Excluye:** el lujo usado como herramienta para seducir a alguien, cuando la seducción ocupa más letra (→ `seduccion_deseo`); el lujo en un contexto de vida criminal o armas como eje (→ `otro`).
- **Ejemplo (candidato — verificar en el piloto):** *Por Esos Ojos* — Fuerza Regida (2025-10).
  - Paráfrasis: El cantante cuenta que salió de la pobreza y presume joyas, lujos y fama, aunque admite que eso no lo llena y le dedica versos a una mujer.
  - Cita: «De la pobreza fui a salvarme» (máx. 6 palabras)
- **Contraejemplo:** *La Diabla* — Xavi (2024-03). Nombra marcas de lujo, pero como oferta para conquistar → `seduccion_deseo`.
  - Paráfrasis: El cantante le ofrece a una mujer ropa de marcas de lujo y todo lo que ella quiera, como parte de su intento de conquistarla.
  - Cita: «Pa' ti me sobra lana» (máx. 6 palabras)

### 2.6 otro
- *Definición operativa:* el eje no corresponde a ninguna de las cinco categorías anteriores (por ejemplo: vida criminal, violencia, identidad o territorio, religión, crítica social).
- *Regla:* usar otro solo cuando ninguna categoría cubra la mayor parte de la letra; no usarlo para casos dudosos entre dos categorías (para eso existe la regla de desempate).
- *Ejemplo:* Si No Quieres No — Luis R. Conriquez y Netón Vega (2024-07).
  - Paráfrasis: El narrador se presenta como hombre leal a unos jefes, armado y dispuesto a la violencia; los carros y las joyas aparecen dentro de ese contexto.
  - Cita: «Tracas, hijo'e su puta madre» (máx. 6 palabras)
- *Contraejemplo:* Por Las Noches — Peso Pluma (2023-09). Menciona alcohol y fiesta, pero el eje es el recuerdo de alguien que se fue → desamor_despecho.
  - Paráfrasis: El cantante recuerda de noche a una mujer que se fue y lo dejó solo; las menciones al alcohol acompañan esa nostalgia.
  - Cita: «Clase Azul es el tequila» (máx. 6 palabras)
---

## 3. Variable `explicito`

**Definición (D2-B):** literal + doble sentido inequívoco.

**Valores válidos:** `si`, `no`

- **`si`** cuando la letra contiene al menos una de estas dos cosas:
  1. **Literal:** nombra de forma directa actos sexuales o partes íntimas en contexto sexual.
  2. **Doble sentido inequívoco:** una expresión cuya **única lectura razonable**, en el contexto de la canción, es sexual.
- **`no`** cuando solo hay:
  - deseo, atracción, besos, baile sensual o insinuaciones **abiertas a más de una lectura**;
  - groserías o lenguaje soez **sin contenido sexual**;
  - menciones del cuerpo o del atractivo sin referencia a un acto sexual.
- **Regla práctica:** si para justificar el `si` hay que decir "puede que se refiera a…", el código es `no` y se explica en `notas`.

| Tipo | Canción | Código | Paráfrasis | Cita |
|---|---|---|---|---|
| Ejemplo literal | *La Jeepeta* — Nio García y otros (2020-10) | `si` | Los cantantes describen sin metáforas lo que quieren hacer sexualmente con una mujer y nombran partes del cuerpo de forma directa. | «_____» |
| Ejemplo doble sentido inequívoco | *Sigues Con Él* — Arcángel y Sech (2020-07) | `si` | La letra usa la imagen de "cocinar" y "comer" para referirse al sexo; en el contexto de la canción no admite otra lectura. | «_____» |
| Contraejemplo (deseo sin acto) | *Hasta el Amanecer* — Nicky Jam (2016-01) | `no` | El cantante le propone a una mujer que acaba de conocer pasar la noche juntos hasta el amanecer, sin describir actos sexuales. | «_____» |
| Contraejemplo (soez no sexual) | *Si No Quieres No* — Luis R. Conriquez y Netón Vega (2024-07) | `no` | La letra usa groserías e insultos fuertes, pero ninguno se refiere a un acto o tema sexual. | «_____» |

### 3.1 Casos límite (se resuelven en la reunión del piloto)
- *Despacito* (2017-01) y *Propuesta Indecente* (2013-05): describen un encuentro íntimo con metáforas e imágenes muy cercanas al acto. Decidir si cruzan la línea del doble sentido inequívoco y anotar aquí la decisión y su razón.
- Mención de nalgas o senos sin acto sexual descrito: decidir si cuenta como "parte íntima en contexto sexual".

---

## 4. Registro de cambios

| Versión | Fecha | Cambio | Motivo |
|---|---|---|---|
| v1 | 2026-10-24 | Versión inicial (desempate: coro, luego jerarquía por especificidad; ejemplos con paráfrasis + cita) | — |
