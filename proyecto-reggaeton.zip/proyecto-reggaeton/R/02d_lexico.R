# =============================================================================
# 02d — Léxico de contenido sexual (instrumento descriptivo, D9)
#
# Decisiones aprobadas por el equipo:
#   D9: léxico inductivo (construido desde las frecuencias del corpus y revisado
#       a mano), conteo por presencia y frecuencia por cada 100 palabras,
#       uso DESCRIPTIVO (contraste con la codificación del LLM, sin pruebas).
#   Instrumento: instrumentos/lexico_explicito_v1.csv
#     - acto_sexual y genitales  -> cuentan como léxico explícito
#     - cuerpo_sexualizado, desnudez, jerga_deseo -> se reportan aparte
# =============================================================================

lexico <- read_csv(file.path(RUTAS$instr, "lexico_explicito_v1.csv"), show_col_types = FALSE)

contar_termino <- function(tokens, patron, tipo) {
  if (tipo == "frase") {
    texto <- paste(tokens, collapse = " ")
    m <- gregexpr(patron, texto, perl = TRUE)[[1]]
    sum(m > 0)
  } else {
    sum(grepl(patron, tokens, perl = TRUE))
  }
}

medidas_lexico <- bind_rows(lapply(names(resultado_texto), function(id) {
  tk <- resultado_texto[[id]]$tokens
  conteos <- vapply(seq_len(nrow(lexico)), function(k)
    contar_termino(tk, lexico$patron[k], lexico$tipo[k]), numeric(1))
  por_cat <- tapply(conteos, lexico$categoria, sum)
  explicito <- sum(conteos[lexico$cuenta_como_explicito == "si"])
  tibble(id = id,
         lex_acto_sexual        = unname(por_cat["acto_sexual"]),
         lex_genitales          = unname(por_cat["genitales"]),
         lex_cuerpo_sexualizado = unname(por_cat["cuerpo_sexualizado"]),
         lex_desnudez           = unname(por_cat["desnudez"]),
         lex_jerga_deseo        = unname(por_cat["jerga_deseo"]),
         lex_explicito_n        = explicito,
         lex_explicito_presencia = if_else(explicito > 0, "si", "no"),
         lex_explicito_por_100  = round(100 * explicito / length(tk), 3))
})) |> arrange(id)
write_csv(medidas_lexico, file.path(RUTAS$proc, "medidas_lexico.csv"))

# Frecuencia de cada término (palabras sueltas, sin letra) en las 147 canciones únicas
ids_unicos <- read_csv(file.path(RUTAS$proc, "canciones_unicas.csv"), show_col_types = FALSE)$id
texto_unicas <- resultado_texto[ids_unicos]
frec_terminos <- lexico |>
  mutate(ocurrencias = vapply(seq_len(n()), function(k)
           sum(vapply(texto_unicas, function(r) contar_termino(r$tokens, patron[k], tipo[k]), numeric(1))), numeric(1)),
         canciones = vapply(seq_len(n()), function(k)
           sum(vapply(texto_unicas, function(r) contar_termino(r$tokens, patron[k], tipo[k]) > 0, logical(1))), numeric(1))) |>
  select(termino, categoria, cuenta_como_explicito, ocurrencias, canciones)
write_csv(frec_terminos, file.path(RUTAS$tablas, "tabla_02d_frecuencia_lexico.csv"))
message("02d: léxico aplicado a ", nrow(medidas_lexico), " letras.")
