# =============================================================================
# 00 — Configuración: paquetes, semilla y rutas
# =============================================================================

if (!file.exists("main.R")) {
  stop("Directorio de trabajo incorrecto. Abre el proyecto con proyecto-reggaeton.Rproj")
}

# El texto de las letras se procesa en UTF-8 (tildes, ñ, apóstrofos)
if (!isTRUE(l10n_info()[["UTF-8"]])) {
  for (loc in c("C.UTF-8", "en_US.UTF-8", "es_CO.UTF-8")) {
    if (nzchar(suppressWarnings(Sys.setlocale("LC_CTYPE", loc)))) break
  }
  if (!isTRUE(l10n_info()[["UTF-8"]])) warning("La sesión de R no está en UTF-8: revisa las tildes en los resultados.")
}

paquetes <- c("dplyr", "readr", "tidyr", "readxl", "tibble", "ggplot2")
faltantes <- paquetes[!paquetes %in% rownames(installed.packages())]
if (length(faltantes) > 0) install.packages(faltantes)
invisible(lapply(paquetes, library, character.only = TRUE))

# Semilla fija del proyecto (debe citarse en el informe)
SEMILLA <- 2026

RUTAS <- list(
  letras = "letras_local",
  raw    = "data/raw",
  proc   = "data/processed",
  val    = "validacion",
  tablas = "output/tablas",
  fig    = "output/figuras",
  instr  = "instrumentos"
)

# Crea las carpetas de trabajo si no existen
invisible(lapply(c(RUTAS, "informe", "divulgacion"), dir.create,
                 recursive = TRUE, showWarnings = FALSE))
