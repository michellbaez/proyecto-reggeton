# =============================================================================
# 06 — Base de datos analítica (entregable 1)
#
# Una fila por canción única (147), con metadatos, medidas de texto, país,
# codificación del LLM y, para la submuestra de validación, la codificación
# humana y el consenso. SIN texto de letras.
# =============================================================================

base_analitica <- read_csv(file.path(RUTAS$proc, "canciones_unicas.csv"), show_col_types = FALSE) |>
  select(id, anio, posicion, titulo, artistas_credito, artista_principal,
         veces_en_top10, era_streaming, uso) |>
  left_join(select(read_csv(file.path(RUTAS$proc, "variables_contexto.csv"), show_col_types = FALSE),
                   id, artista_normalizado, pais_origen_artistico, pais_s1), by = "id") |>
  left_join(select(read_csv(file.path(RUTAS$proc, "medidas_texto.csv"), show_col_types = FALSE),
                   id, n_tokens, n_tipos, ttr, mtld), by = "id") |>
  left_join(read_csv(file.path(RUTAS$proc, "medidas_lexico.csv"), show_col_types = FALSE), by = "id")

if (file.exists(file.path(RUTAS$proc, "codificacion_llm.csv"))) {
  base_analitica <- base_analitica |>
    left_join(read_csv(file.path(RUTAS$proc, "codificacion_llm.csv"), show_col_types = FALSE) |>
                select(id, tema_llm, explicito_sexual_llm), by = "id")
}
archivo_val <- file.path(RUTAS$tablas, "tabla_04_validacion_instrumento.csv")
if (file.exists(archivo_val)) {
  base_analitica <- base_analitica |>
    left_join(read_csv(archivo_val, show_col_types = FALSE) |>
                select(id, any_of(c("tema_J", "tema_S", "tema_C", "expl_J", "expl_S", "expl_C"))) |>
                rename(any_of(c(tema_jari = "tema_J", tema_silvio = "tema_S", tema_consenso = "tema_C",
                                explicito_jari = "expl_J", explicito_silvio = "expl_S",
                                explicito_consenso = "expl_C"))), by = "id")
}

stopifnot(nrow(base_analitica) == 147, !anyDuplicated(base_analitica$id))
write_csv(base_analitica, file.path("data", "base_analitica.csv"), na = "")

# Descriptivos para el informe
if ("explicito_sexual_llm" %in% names(base_analitica)) {
  write_csv(base_analitica |> group_by(era_streaming) |>
              summarise(n = n(), explicitas = sum(explicito_sexual_llm == "si"),
                        proporcion = round(explicitas / n, 3), .groups = "drop"),
            file.path(RUTAS$tablas, "tabla_06_explicito_por_era.csv"))
  write_csv(base_analitica |> group_by(anio) |>
              summarise(n = n(), proporcion_explicitas = round(mean(explicito_sexual_llm == "si"), 3),
                        mediana_mtld = median(mtld), .groups = "drop"),
            file.path(RUTAS$tablas, "tabla_06_resumen_anual.csv"))
}
# Contraste descriptivo léxico vs. LLM (D9: sin prueba de hipótesis)
if ("explicito_sexual_llm" %in% names(base_analitica)) {
  write_csv(as.data.frame.matrix(table(lexico = base_analitica$lex_explicito_presencia,
                                       llm = base_analitica$explicito_sexual_llm)) |>
              tibble::rownames_to_column("lexico_explicito"),
            file.path(RUTAS$tablas, "tabla_06_lexico_vs_llm.csv"))
  write_csv(base_analitica |> group_by(era_streaming) |>
              summarise(n = n(), con_lexico_explicito = sum(lex_explicito_presencia == "si"),
                        mediana_por_100 = median(lex_explicito_por_100), .groups = "drop"),
            file.path(RUTAS$tablas, "tabla_06_lexico_por_era.csv"))
}
message("06: base analítica exportada (data/base_analitica.csv, 147 filas).")
