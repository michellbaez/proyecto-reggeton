# =============================================================================
# 03 — Codificación con el LLM (instrumento de medición)
#
# Decisiones aprobadas por el equipo:
#   D11: ejecución sin costo — Claude codificó las 147 canciones en la sesión
#        de trabajo del proyecto (no por API); no se pudo fijar la temperatura.
#   D12: prompt fijo = instrumentos/prompt_codificacion_v1.txt (basado en el
#        libro de códigos v2); salida {tema_principal, explicito_sexual, justificacion}
#   D13: sin segundo modelo por ahora.
# =============================================================================

METADATOS_LLM <- tibble(
  instrumento      = "Claude (Anthropic)",
  modelo           = "claude-opus-5-5 (Claude Opus 5.5)",
  fecha_ejecucion  = "2026-10-24",
  modo             = "Sesión de trabajo, sin API; temperatura no controlable",
  prompt           = "instrumentos/prompt_codificacion_v1.txt",
  libro_codigos    = "instrumentos/libro_codigos_v2.md",
  entrada          = "Letra limpia (reglas 02a), líneas repetidas mostradas una vez con su número de repeticiones",
  agrupamiento     = "Canciones leídas en lotes de 12 a 23 dentro de la misma sesión (no una llamada independiente por canción)",
  canciones        = 147L
)

archivo_llm <- file.path(RUTAS$raw, "codificacion_llm_claude.csv")

if (!file.exists(archivo_llm)) {
  message("03: no está ", archivo_llm, "; se omite la codificación del LLM.")
} else {
  TEMAS_VALIDOS <- c("amor_romance", "desamor_despecho", "seduccion_deseo",
                     "fiesta_baile", "ostentacion_exito", "otro")

  llm <- read_csv(archivo_llm, col_types = cols(.default = col_character()))
  canciones_llm <- read_csv(file.path(RUTAS$proc, "canciones_unicas.csv"), show_col_types = FALSE)

  stopifnot(
    setequal(llm$id, canciones_llm$id), !anyDuplicated(llm$id),
    all(llm$tema_principal %in% TEMAS_VALIDOS),
    all(llm$explicito_sexual %in% c("si", "no"))
  )

  codificacion_llm <- llm |>
    transmute(id, tema_llm = tema_principal, explicito_sexual_llm = explicito_sexual,
              justificacion_llm = justificacion) |>
    arrange(id)
  write_csv(codificacion_llm, file.path(RUTAS$proc, "codificacion_llm.csv"))
  write_csv(METADATOS_LLM,    file.path(RUTAS$tablas, "metadatos_codificacion_llm.csv"))

  # Descriptivo
  dist_llm <- codificacion_llm |>
    left_join(select(canciones_llm, id, era_streaming), by = "id") |>
    count(era_streaming, tema_llm, explicito_sexual_llm)
  write_csv(dist_llm, file.path(RUTAS$tablas, "tabla_03_distribucion_llm_sin_validar.csv"))

  message("03: codificación del LLM importada (", nrow(codificacion_llm), " canciones).")
}
