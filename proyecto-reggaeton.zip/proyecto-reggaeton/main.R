# =============================================================================
# Estadística del Reggaetón — Script maestro
# Ejecuta todo el flujo en orden, desde cero, en una sesión limpia.
# Uso: abrir proyecto-reggaeton.Rproj y ejecutar  source("main.R")
# =============================================================================

rm(list = ls())

source("R/00_configuracion.R")
source("R/01_marco_muestral.R")
source("R/01b_plantillas_codificacion.R")
source("R/02a_limpieza_texto.R")
source("R/02b_medidas_texto.R")
source("R/02c_pais_artista.R")
source("R/02d_lexico.R")
source("R/03_codificacion_llm.R")
source("R/04a_piloto_acuerdo.R")


source("R/04_validacion_kappa.R")
source("R/05_analisis_inferencial.R")
source("R/06_base_analitica.R")
source("R/07_figuras.R")

# Registro de versiones (reproducibilidad)
writeLines(capture.output(sessionInfo()), "output/sessionInfo.txt")
message("Flujo completo ejecutado sin errores.")
