# =============================================================================
# 01 — Marco muestral, control del corpus y submuestra de validación
#
# =============================================================================

# --- 1. Marco --------------------------------------------------------------
marco <- read_csv(file.path(RUTAS$raw, "marco_top10_hotlatin.csv"),
                  show_col_types = FALSE) |>
  mutate(era_streaming = if_else(anio >= 2013, "streaming", "pre_streaming"))

stopifnot(
  nrow(marco) == 160,
  all(count(marco, anio)$n == 10),
  !anyDuplicated(marco$id)
)

# --- 2. Control del corpus de letras ---------------------------------------
# Acepta archivos en subcarpetas por año y nombres "2010-01" o "2010_01"
rutas_txt  <- list.files(RUTAS$letras, pattern = "\\.txt$",
                         recursive = TRUE, full.names = TRUE)
inventario <- tibble(
  ruta  = rutas_txt,
  id    = gsub("_", "-", tools::file_path_sans_ext(basename(rutas_txt))),
  bytes = file.size(rutas_txt)
)

problemas <- list(
  duplicados = inventario$id[duplicated(inventario$id)],
  faltan     = setdiff(marco$id, inventario$id),
  sobran     = setdiff(inventario$id, marco$id),
  vacios     = inventario$id[inventario$bytes == 0]
)
if (any(lengths(problemas) > 0)) {
  print(problemas[lengths(problemas) > 0])
  stop("Corpus incompleto o inconsistente: revisa la carpeta letras_local/")
}
message("Corpus OK: 160 archivos de letras encontrados.")

write_csv(marco, file.path(RUTAS$proc, "marco_160.csv"))

# --- 3. Unidad de análisis: canciones únicas --------------------------------
canciones <- marco |> filter(primera_aparicion == "si")
stopifnot(nrow(canciones) == 147)

# --- 4. Submuestra de validación ----------------------------
set.seed(SEMILLA)
val_base  <- canciones |> group_by(anio) |> slice_sample(n = 3) |> ungroup()
val_extra <- canciones |> anti_join(val_base, by = "id") |> slice_sample(n = 2)

canciones <- canciones |>
  mutate(
    en_validacion  = id %in% c(val_base$id, val_extra$id),
    tipo_seleccion = case_when(
      id %in% val_base$id  ~ "3_por_anio",
      id %in% val_extra$id ~ "extra_global",
      TRUE                 ~ NA_character_
    )
  )
stopifnot(sum(canciones$en_validacion) == 50)

# --- 4.2 Prueba piloto ----------------
set.seed(SEMILLA + 1)
piloto <- canciones |> filter(!en_validacion) |> slice_sample(n = 5)
canciones <- canciones |>
  mutate(
    en_piloto = id %in% piloto$id,
    uso = case_when(en_validacion ~ "validacion",
                    en_piloto     ~ "piloto",
                    TRUE          ~ "solo_llm")
  )
stopifnot(sum(canciones$en_piloto) == 5, !any(canciones$en_piloto & canciones$en_validacion))

write_csv(canciones, file.path(RUTAS$proc, "canciones_unicas.csv"), na = "")

# --- 5. Tablas para el informe ---------------------------------
tabla_era  <- canciones |> count(era_streaming, uso)
tabla_anio <- canciones |>
  group_by(anio) |>
  summarise(canciones_unicas = n(), en_validacion = sum(en_validacion),
            en_piloto = sum(en_piloto), .groups = "drop")

write_csv(tabla_era,  file.path(RUTAS$tablas, "tabla_01a_diseno_por_era.csv"))
write_csv(tabla_anio, file.path(RUTAS$tablas, "tabla_01b_diseno_por_anio.csv"))
print(tabla_era)
print(tabla_anio, n = 16)
