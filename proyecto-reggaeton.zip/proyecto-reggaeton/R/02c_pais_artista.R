# =============================================================================
# 02c — País del artista principal (variable de contexto para S1)
#
# Decisiones aprobadas por el equipo:
#   - Fuente: data/raw/paises_artistas.csv (un registro por cada forma en que
#     el artista principal aparece escrito en el marco)
#   - Se clasifica con la columna pais_origen_artistico (no la de nacimiento)
#   - Categorías para S1: colombia / puerto_rico / otro
#   - El documento base conserva el país completo de cada artista
# =============================================================================

paises <- read_csv(file.path(RUTAS$raw, "paises_artistas.csv"), show_col_types = FALSE)
marco_160 <- read_csv(file.path(RUTAS$proc, "marco_160.csv"), show_col_types = FALSE)

sin_pais <- setdiff(unique(marco_160$artista_principal), paises$artista_principal)
if (length(sin_pais) > 0) {
  print(sin_pais)
  stop("Hay artistas del marco sin país en data/raw/paises_artistas.csv")
}
stopifnot(!anyDuplicated(paises$artista_principal),
          !any(is.na(paises$pais_origen_artistico)))

contexto <- read_csv(file.path(RUTAS$proc, "canciones_unicas.csv"), show_col_types = FALSE) |>
  left_join(select(paises, artista_principal, artista_normalizado,
                   pais_origen_artistico, caso_ambiguo),
            by = "artista_principal") |>
  mutate(pais_s1 = case_when(
    pais_origen_artistico == "Colombia"    ~ "colombia",
    pais_origen_artistico == "Puerto Rico" ~ "puerto_rico",
    TRUE                                   ~ "otro"
  )) |>
  select(id, anio, era_streaming, artista_normalizado,
         pais_origen_artistico, pais_s1, caso_ambiguo)

stopifnot(nrow(contexto) == 147)
write_csv(contexto, file.path(RUTAS$proc, "variables_contexto.csv"))

tabla_pais <- contexto |> count(pais_s1, era_streaming) |>
  tidyr::pivot_wider(names_from = era_streaming, values_from = n, values_fill = 0) |>
  mutate(total = pre_streaming + streaming)
tabla_paises_detalle <- contexto |> count(pais_origen_artistico, sort = TRUE)

write_csv(tabla_pais,           file.path(RUTAS$tablas, "tabla_02c_pais_s1_por_era.csv"))
write_csv(tabla_paises_detalle, file.path(RUTAS$tablas, "tabla_02c_paises_detalle.csv"))
print(tabla_pais)
