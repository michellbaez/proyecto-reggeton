# =============================================================================
# 04a — Acuerdo entre codificadores humanos en la PRUEBA PILOTO
#
# Calcula, para tema_principal y explicito_sexual (el piloto usó el libro v1):
#   - acuerdo observado  p_o
#   - acuerdo esperado por azar  p_e  (a partir de las marginales de cada codificador)
#   - kappa de Cohen  κ = (p_o - p_e) / (1 - p_e)
#   - tabla de confusión y lista de desacuerdos con las nota
# =============================================================================

leer_hoja_codificacion <- function(archivo) {
  encabezado <- readLines(archivo, n = 1, encoding = "UTF-8", warn = FALSE)
  separador  <- if (grepl(";", encabezado)) ";" else ","
  hoja <- read_delim(archivo, delim = separador, col_types = cols(.default = col_character()),
                     locale = locale(encoding = "UTF-8"), trim_ws = TRUE)

  # id convertido en fecha por Excel: d/mm/aaaa -> aaaa-mm
  es_fecha <- grepl("^\\d{1,2}/\\d{1,2}/\\d{4}$", hoja$id)
  if (any(es_fecha)) {
    partes <- strsplit(hoja$id[es_fecha], "/")
    hoja$id[es_fecha] <- vapply(partes, function(p) sprintf("%s-%02d", p[3], as.integer(p[2])), "")
    message(basename(archivo), ": ", sum(es_fecha), " ids convertidos en fecha por Excel fueron corregidos.")
  }

  # El piloto se codificó con el libro v1 (columna "explicito");
  # desde el libro v2 la columna se llama "explicito_sexual"
  if ("explicito" %in% names(hoja) && !"explicito_sexual" %in% names(hoja)) {
    hoja <- rename(hoja, explicito_sexual = explicito)
  }

  normalizar <- function(x) {
    x[is.na(x)] <- ""                       # celdas vacías llegan como NA
    x <- tolower(trimws(x))
    x <- iconv(x, from = "UTF-8", to = "ASCII//TRANSLIT")
    gsub("[^a-z_]", "", x)
  }
  hoja |> mutate(tema_principal = normalizar(tema_principal),
                 explicito_sexual = normalizar(explicito_sexual))
}

kappa_cohen <- function(a, b) {
  niveles <- sort(union(a, b))
  tabla   <- table(factor(a, niveles), factor(b, niveles))
  n   <- sum(tabla)
  p_o <- sum(diag(tabla)) / n
  p_e <- sum(rowSums(tabla) * colSums(tabla)) / n^2
  list(n = n, p_o = p_o, p_e = p_e, kappa = (p_o - p_e) / (1 - p_e), tabla = tabla)
}

archivos_piloto <- file.path(RUTAS$val, c("piloto_Jari.csv", "piloto_Silvio.csv"))

if (all(file.exists(archivos_piloto))) {
  jari   <- leer_hoja_codificacion(archivos_piloto[1])
  silvio <- leer_hoja_codificacion(archivos_piloto[2])

  hoja_completa <- function(h) nrow(h) > 0 && all(nzchar(h$tema_principal)) && all(nzchar(h$explicito_sexual))

  if (hoja_completa(jari) && hoja_completa(silvio)) {
    piloto <- inner_join(
      select(jari,   id, titulo, tema_J = tema_principal, explicito_J = explicito_sexual, notas_J = notas),
      select(silvio, id,         tema_S = tema_principal, explicito_S = explicito_sexual, notas_S = notas),
      by = "id"
    )
    stopifnot(nrow(piloto) == 5)

    k_tema <- kappa_cohen(piloto$tema_J, piloto$tema_S)
    k_expl <- kappa_cohen(piloto$explicito_J, piloto$explicito_S)

    resumen_piloto <- tibble(
      variable = c("tema_principal", "explicito_sexual"),
      n        = c(k_tema$n, k_expl$n),
      p_o      = round(c(k_tema$p_o, k_expl$p_o), 3),
      p_e      = round(c(k_tema$p_e, k_expl$p_e), 3),
      kappa    = round(c(k_tema$kappa, k_expl$kappa), 3)
    )

    comparacion_piloto <- piloto |>
      mutate(acuerdo_tema = tema_J == tema_S,
             acuerdo_explicito_sexual = explicito_J == explicito_S)

    write_csv(resumen_piloto,     file.path(RUTAS$tablas, "piloto_kappa.csv"))
    write_csv(comparacion_piloto, file.path(RUTAS$tablas, "piloto_comparacion.csv"), na = "")

    print(resumen_piloto)
    cat("\nTabla de confusión — tema_principal (filas: Jari, columnas: Silvio)\n"); print(k_tema$tabla)
    cat("\nTabla de confusión — explicito_sexual (filas: Jari, columnas: Silvio)\n");      print(k_expl$tabla)
  } else {
    message("Piloto: las hojas de validacion/ aún tienen celdas vacías en tema_principal o explicito_sexual; ",
            "se omite el cálculo. Reemplácenlas por las hojas llenas del piloto.")
  }
}
