# =============================================================================
# 05 — Análisis inferencial
#
# Decisiones aprobadas por el equipo:
#   Principal: Mann-Kendall sobre la mediana anual del MTLD + pendiente de Sen
#   S1:        Mann-Whitney Colombia vs. Puerto Rico, solo era streaming (2013–2025);
#              efecto = correlación biserial-rango
#   S2a:       tema_principal × era_streaming con prueba exacta de Fisher; efecto = V de Cramér
#   S2b:       regresión logística explicito_sexual ~ año; efecto = OR por año con IC 95 % (Wald)
#   D17:       α = 0.05 con corrección de Holm sobre las pruebas ejecutadas
#   S2a y S2b solo se ejecutan si la variable pasó el umbral de validez (módulo 04).
# =============================================================================

ALFA <- 0.05

base <- read_csv(file.path(RUTAS$proc, "variables_contexto.csv"), show_col_types = FALSE) |>
  left_join(read_csv(file.path(RUTAS$proc, "medidas_texto.csv"), show_col_types = FALSE), by = "id")
stopifnot(nrow(base) == 147)

resultados <- list()

# --- Principal: tendencia del MTLD (Mann-Kendall + Sen) -------------------------
serie <- base |> group_by(anio) |> summarise(mediana_mtld = median(mtld), n = n(), .groups = "drop")
mk <- cor.test(serie$anio, serie$mediana_mtld, method = "kendall")   # Mann-Kendall = Kendall τ vs. tiempo
pares <- combn(nrow(serie), 2)
sen <- median((serie$mediana_mtld[pares[2, ]] - serie$mediana_mtld[pares[1, ]]) /
              (serie$anio[pares[2, ]] - serie$anio[pares[1, ]]))
resultados$principal <- tibble(
  pregunta = "Principal", prueba = "Mann-Kendall (mediana anual del MTLD, 16 años)",
  estadistico = unname(mk$statistic), p_valor = mk$p.value,
  efecto = "tau de Kendall", valor_efecto = unname(mk$estimate),
  efecto_2 = "pendiente de Sen (MTLD por año)", valor_efecto_2 = sen)
write_csv(serie, file.path(RUTAS$tablas, "tabla_05_serie_anual_mtld.csv"))

# --- S1: Colombia vs. Puerto Rico (era streaming) -------------------------------
s1 <- base |> filter(era_streaming == "streaming", pais_s1 %in% c("colombia", "puerto_rico"))
mw <- wilcox.test(mtld ~ pais_s1, data = s1, exact = FALSE)
n_co <- sum(s1$pais_s1 == "colombia"); n_pr <- sum(s1$pais_s1 == "puerto_rico")
r_rb <- 2 * unname(mw$statistic) / (n_co * n_pr) - 1     # >0: Colombia tiende a mayor MTLD
resultados$s1 <- tibble(
  pregunta = "S1", prueba = sprintf("Mann-Whitney (Colombia n=%d vs. Puerto Rico n=%d, 2013–2025)", n_co, n_pr),
  estadistico = unname(mw$statistic), p_valor = mw$p.value,
  efecto = "correlación biserial-rango", valor_efecto = r_rb,
  efecto_2 = "diferencia de medianas (CO - PR)",
  valor_efecto_2 = median(s1$mtld[s1$pais_s1 == "colombia"]) - median(s1$mtld[s1$pais_s1 == "puerto_rico"]))
write_csv(s1 |> group_by(pais_s1) |> summarise(n = n(), mediana_mtld = median(mtld),
                                              q1 = quantile(mtld, .25), q3 = quantile(mtld, .75)),
          file.path(RUTAS$tablas, "tabla_05_s1_descriptivos.csv"))

# --- S2: solo variables validadas ----------------------------------------------
archivo_validez <- file.path(RUTAS$tablas, "tabla_04_validez_instrumento.csv")
if (file.exists(archivo_validez)) {
  validez <- read_csv(archivo_validez, show_col_types = FALSE)
  base <- base |> left_join(read_csv(file.path(RUTAS$proc, "codificacion_llm.csv"), show_col_types = FALSE), by = "id")

  if (isTRUE(validez$valida[validez$variable == "tema"])) {
    tab <- table(base$tema_llm, base$era_streaming)
    set.seed(SEMILLA)
    fi <- fisher.test(tab, simulate.p.value = TRUE, B = 1e5)
    chi <- suppressWarnings(chisq.test(tab, correct = FALSE))
    v_cramer <- sqrt(unname(chi$statistic) / (sum(tab) * (min(dim(tab)) - 1)))
    resultados$s2a <- tibble(
      pregunta = "S2a", prueba = "Fisher exacta (Monte Carlo, 100.000 réplicas): tema × era",
      estadistico = NA_real_, p_valor = fi$p.value,
      efecto = "V de Cramér", valor_efecto = v_cramer,
      efecto_2 = "frecuencia esperada mínima", valor_efecto_2 = min(chi$expected))
    write_csv(as.data.frame.matrix(tab) |> tibble::rownames_to_column("tema"),
              file.path(RUTAS$tablas, "tabla_05_s2a_tema_por_era.csv"))
  } else message("05: tema_principal no pasó el umbral de validez; S2a no se ejecuta.")

  if (isTRUE(validez$valida[validez$variable == "explicito_sexual"])) {
    modelo <- glm(I(explicito_sexual_llm == "si") ~ anio, data = base, family = binomial)
    ic <- exp(confint.default(modelo)["anio", ])
    resultados$s2b <- tibble(
      pregunta = "S2b", prueba = "Regresión logística: explicito_sexual ~ año",
      estadistico = summary(modelo)$coefficients["anio", "z value"],
      p_valor = summary(modelo)$coefficients["anio", "Pr(>|z|)"],
      efecto = "OR por año", valor_efecto = exp(coef(modelo)["anio"]),
      efecto_2 = "IC 95 % del OR", valor_efecto_2 = NA_real_,
      ic_or = sprintf("%.3f – %.3f", ic[1], ic[2]))
  } else message("05: explicito_sexual no pasó el umbral de validez; S2b no se ejecuta.")
} else {
  message("05: aún no hay decisión de validez (módulo 04 sin consenso); S2 no se ejecuta.")
}

# --- Holm (D17) ------------------------------------------------------------------
tabla_resultados <- bind_rows(resultados) |>
  mutate(p_holm = p.adjust(p_valor, method = "holm"),
         significativo_holm = p_holm < ALFA,
         across(where(is.numeric), ~ round(.x, 4)))
write_csv(tabla_resultados, file.path(RUTAS$tablas, "tabla_05_resultados_inferenciales.csv"), na = "")
print(tabla_resultados |> select(pregunta, p_valor, p_holm, efecto, valor_efecto, efecto_2, valor_efecto_2))
