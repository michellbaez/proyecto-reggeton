# =============================================================================
# 04 — Validación del instrumento (50 canciones)
#
# Decisiones aprobadas por el equipo:
#   D14-B: consenso humano por discusión entre Jari y Silvio
#          (validacion/consenso_desacuerdos.xlsx); donde coincidieron, ese
#          código es el consenso.
#   D15:   kappa de Cohen con IC 95 % asintótico (Fleiss, Cohen y Everitt, 1969)
#   D16:   una variable es válida si κ(Claude vs. consenso) >= 0.61
# =============================================================================

UMBRAL_KAPPA <- 0.61
TEMAS_VALIDOS <- c("amor_romance", "desamor_despecho", "seduccion_deseo",
                   "fiesta_baile", "ostentacion_exito", "otro")

# Error estándar asintótico de kappa (Fleiss, Cohen y Everitt)
kappa_ic <- function(a, b, nivel = 0.95) {
  k <- kappa_cohen(a, b)
  p  <- k$tabla / k$n
  pf <- rowSums(p); pc <- colSums(p); kap <- k$kappa; pe <- k$p_e
  A <- sum(diag(p) * (1 - (pf + pc) * (1 - kap))^2)
  fuera <- outer(pc, pf, "+")                  # celda (i, j): p_.i + p_j.
  B <- (1 - kap)^2 * sum((p * fuera^2)[row(p) != col(p)])
  C <- (kap - pe * (1 - kap))^2
  se <- sqrt((A + B - C) / k$n) / (1 - pe)
  z  <- qnorm(1 - (1 - nivel) / 2)
  list(n = k$n, p_o = k$p_o, p_e = pe, kappa = kap, se = se,
       ic_inf = kap - z * se, ic_sup = kap + z * se, tabla = k$tabla)
}

# Prueba de control del error estándar (verificada a mano y con una implementación
# independiente): tabla 2x2 con p = [.5 .1; .1 .3] -> κ = 0.5833, EE = 0.1173
local({
  a <- c(rep("si", 30), rep("no", 20))
  b <- c(rep("si", 25), rep("no", 5), rep("si", 5), rep("no", 15))
  r <- kappa_ic(a, b)
  stopifnot(abs(r$kappa - 0.5833) < 1e-3, abs(r$se - 0.1173) < 1e-3)
})

archivos_val <- file.path(RUTAS$val, c("codificacion_Jari.csv", "codificacion_Silvio.csv"))
archivo_llm_proc <- file.path(RUTAS$proc, "codificacion_llm.csv")

if (all(file.exists(archivos_val)) && file.exists(archivo_llm_proc)) {

  jari_v   <- leer_hoja_codificacion(archivos_val[1])
  silvio_v <- leer_hoja_codificacion(archivos_val[2])
  for (h in list(jari_v, silvio_v)) {
    malos <- setdiff(c(h$tema_principal, h$explicito_sexual), c(TEMAS_VALIDOS, "si", "no"))
    if (length(malos) > 0) stop("Códigos inválidos en las hojas de validación: ", paste(malos, collapse = ", "))
  }

  llm_v <- read_csv(archivo_llm_proc, show_col_types = FALSE)
  val <- inner_join(
    select(jari_v,   id, titulo, tema_J = tema_principal, expl_J = explicito_sexual, nota_J = notas),
    select(silvio_v, id,         tema_S = tema_principal, expl_S = explicito_sexual, nota_S = notas),
    by = "id") |>
    left_join(select(llm_v, id, tema_L = tema_llm, expl_L = explicito_sexual_llm,
                     justificacion_llm), by = "id")
  stopifnot(nrow(val) == 50, !any(is.na(val$tema_L)))

  # --- Consenso (D14-B) -------------------------------------------------------
  archivo_cons <- file.path(RUTAS$val, "consenso_desacuerdos.xlsx")
  cons <- if (file.exists(archivo_cons)) {
    readxl::read_excel(archivo_cons, sheet = "desacuerdos", col_types = "text") |>
      mutate(consenso = tolower(trimws(coalesce(consenso, ""))))
  } else NULL

  # El equipo escribió el consenso como texto libre ("El consenso es desamor",
  # "Sí es explícito"). Se traduce al código con reglas de palabras clave
  interpretar_consenso <- function(texto, variable) {
    x <- iconv(tolower(trimws(texto)), from = "UTF-8", to = "ASCII//TRANSLIT")
    if (x %in% c(TEMAS_VALIDOS, "si", "no")) return(x)
    if (variable == "explicito_sexual") {
      if (grepl("^no\\b|no es explicit", x)) return("no")
      if (grepl("^si\\b", x)) return("si")
      return(NA_character_)
    }
    if (grepl("desamor|despecho", x))  return("desamor_despecho")
    if (grepl("seduc|deseo", x))       return("seduccion_deseo")
    if (grepl("ostent", x))            return("ostentacion_exito")
    if (grepl("fiesta|baile", x))      return("fiesta_baile")
    if (grepl("romance|amor", x))      return("amor_romance")
    if (grepl("\\botro\\b", x))         return("otro")
    NA_character_
  }

  consenso_completo <- !is.null(cons) && all(cons$consenso != "")
  if (consenso_completo) {
    cons <- cons |>
      mutate(consenso_texto = consenso,
             consenso = mapply(interpretar_consenso, consenso_texto, variable, USE.NAMES = FALSE))
    write_csv(select(cons, id, titulo, variable, codigo_Jari, codigo_Silvio, consenso_texto,
                     consenso_codigo = consenso, razon_consenso),
              file.path(RUTAS$tablas, "reporte_04_consenso_interpretado.csv"), na = "")
    if (any(is.na(cons$consenso))) {
      print(filter(cons, is.na(consenso)) |> select(id, variable, consenso_texto))
      stop("No se pudo interpretar el consenso de estas filas: escriban el código exacto.")
    }
    cons_t <- filter(cons, variable == "tema_principal")   |> select(id, cons_tema = consenso, razon_tema = razon_consenso)
    cons_e <- filter(cons, variable == "explicito_sexual") |> select(id, cons_expl = consenso, razon_expl = razon_consenso)
    val <- val |>
      left_join(cons_t, by = "id") |> left_join(cons_e, by = "id") |>
      mutate(tema_C = if_else(tema_J == tema_S, tema_J, cons_tema),
             expl_C = if_else(expl_J == expl_S, expl_J, cons_expl))
    stopifnot(!any(is.na(val$tema_C)), !any(is.na(val$expl_C)))
  } else {
    message("04: la hoja de consenso está incompleta; se calculan solo los kappas sin consenso.")
  }

  # --- Kappas -------------------------------------------------------------------
  comparaciones <- list(
    "Jari vs. Silvio"  = c("J", "S"),
    "Claude vs. Jari"  = c("L", "J"),
    "Claude vs. Silvio"= c("L", "S")
  )
  if (consenso_completo) comparaciones <- c(list("Claude vs. consenso" = c("L", "C")), comparaciones)

  kappas <- bind_rows(lapply(names(comparaciones), function(nm) {
    q <- comparaciones[[nm]]
    bind_rows(lapply(c(tema = "tema", explicito_sexual = "expl"), function(v) {
      r <- kappa_ic(val[[paste0(v, "_", q[1])]], val[[paste0(v, "_", q[2])]])
      tibble(comparacion = nm, n = r$n, p_o = r$p_o, p_e = r$p_e,
             kappa = r$kappa, ic95_inf = r$ic_inf, ic95_sup = r$ic_sup)
    }), .id = "variable")
  })) |> mutate(across(p_o:ic95_sup, ~ round(.x, 3)))
  write_csv(kappas, file.path(RUTAS$tablas, "tabla_04_kappas.csv"))
  print(kappas)

  # --- Decisión de validez (D16) y tablas de confusión -------------------------
  if (consenso_completo) {
    validez <- kappas |>
      filter(comparacion == "Claude vs. consenso") |>
      transmute(variable, kappa, ic95_inf, ic95_sup, umbral = UMBRAL_KAPPA,
                valida = kappa >= UMBRAL_KAPPA)
    write_csv(validez, file.path(RUTAS$tablas, "tabla_04_validez_instrumento.csv"))
    print(validez)

    sufijos <- c(tema = "tema", explicito_sexual = "expl")
    for (nombre in names(sufijos)) {
      v <- sufijos[[nombre]]
      tabla <- table(Claude = val[[paste0(v, "_L")]], Consenso = val[[paste0(v, "_C")]])
      write_csv(as.data.frame.matrix(tabla) |> tibble::rownames_to_column("Claude"),
                file.path(RUTAS$tablas, paste0("tabla_04_confusion_", nombre, ".csv")))
    }
  }

  # --- Tabla de validación -
  tabla_validacion <- val |>
    mutate(acuerdo_humano_tema = tema_J == tema_S,
           acuerdo_humano_expl = expl_J == expl_S)
  write_csv(tabla_validacion, file.path(RUTAS$tablas, "tabla_04_validacion_instrumento.csv"), na = "")
}
