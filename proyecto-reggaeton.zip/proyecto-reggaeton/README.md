# Estadística del Reggaetón

Proyecto 3 · Estadística Industrial · Universidad del Magdalena · 2026-II

## Preguntas de investigación
- **Principal:** ¿Cómo ha cambiado la diversidad léxica (MTLD) de las letras de las 10 canciones latinas más populares de cada año entre 2010 y 2025?
- **S1:** ¿Difiere la diversidad léxica entre artistas colombianos y puertorriqueños (2013–2025)?
- **S2:** ¿Qué temáticas principales predominan y ha cambiado la proporción de canciones con contenido sexual explícito?

## Cómo ejecutar (sesión limpia)
1. Copiar las letras en `letras_local/` (no se incluyen: derechos de autor).
2. Abrir `proyecto-reggaeton.Rproj` en RStudio.
3. Ejecutar `source("main.R")`. Los paquetes faltantes se instalan solos (dplyr, readr, tidyr, readxl, tibble, ggplot2).

## Flujo (`main.R`)
| Módulo | Qué hace |
|---|---|
| `00_configuracion.R` | Paquetes, semilla (2026), rutas |
| `01_marco_muestral.R` | Marco (160), control del corpus, 147 canciones únicas, validación (50) y piloto (5) |
| `01b_plantillas_codificacion.R` | Hojas de codificación humana |
| `02a_limpieza_texto.R` | Limpieza en memoria (encabezados, etiquetas, marcas x2) con reporte |
| `02b_medidas_texto.R` | Normalización (D7) y MTLD (D8) |
| `02c_pais_artista.R` | País por origen artístico (Colombia / Puerto Rico / otro) |
| `02d_lexico.R` | Léxico de contenido sexual (descriptivo) |
| `03_codificacion_llm.R` | Importa y verifica la codificación de Claude |
| `04a_piloto_acuerdo.R` | Kappa del piloto |
| `04_validacion_kappa.R` | Kappas con IC asintótico, consenso, umbral 0.61, tabla de validación |
| `05_analisis_inferencial.R` | Mann-Kendall + Sen, Mann-Whitney, Fisher, regresión logística, Holm |
| `06_base_analitica.R` | Base analítica (`data/base_analitica.csv`) |
| `07_figuras.R` | Figuras del informe |

## Entregables
| # | Entregable | Ubicación |
|---|---|---|
| 1 | Base de datos analítica | `data/base_analitica.csv` |
| 2 | Léxico y libro de códigos | `instrumentos/lexico_explicito_v1.csv`, `instrumentos/libro_codigos_v1.md`, `instrumentos/libro_codigos_v2.md` |
| 3 | Repositorio de código | este proyecto |
| 4 | Tabla de validación | `output/tablas/tabla_04_validacion_instrumento.csv`, `tabla_04_kappas.csv`, `tabla_04_confusion_*.csv`, `validacion/` |
| 5 | Informe técnico | `informe/` |
| 6 | Producto de divulgación | `divulgacion/` |
| 7 | Bitácora de IA | `Bitacora IA reggaeton.xlsx` |

## Regla de manejo de letras
El código procesa las letras en memoria y exporta solo estadísticos derivados. Ningún archivo del repositorio contiene letras completas.
